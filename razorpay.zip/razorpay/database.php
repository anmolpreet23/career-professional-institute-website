<?php
$cookie_value = "name";
setcookie("name", $cookie_value, time() + (86400 * 30), "/"); //86400 = 1
session_start();
$error = '';
$servername = ("localhost");
$username = ("root");
$password = ("");
$dbname = ("doc2doors");
$conn =  mysqli_connect($servername, $username, $password);
mysqli_select_db($conn, 'doc2doors');
//connection








































// if (isset($_POST['submitform'])) {
   // $nameofpatient = $_POST["Name_Of_Patient"];
    //$phonenumber =
    //$_POST['Phonenumber'];
    //$emailid =
    //$_POST['Email_ID'];
    //$sex
    //= $_POST['Sex'];
    //$age
    //= $_POST['Age'];
    //$bloodgroup =
    // $_POST['Blood_Group'];
    //$weight =
    //$_POST['_Weight'];
    //$height =
    //$_POST['Height'];
    //$date =
    // $_POST['_Date'];
    // $time =
    // $_POST['_Time'];
    //$textarea =
    // $_POST['Text-Area'];

    //$sqlinsert = "INSERT INTO bookingform ('Name_Of_Patient') VALUES ($nameofpatient)";

    //if (!mysqli_query($conn, $sqlinsert)) {
      //  die('error inserting data');
    //}
    //$newrecord = "1 record added to database";
//}//end of main if statement
