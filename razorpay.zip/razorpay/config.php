<?php

$api_key_id = 'rzp_live_MqktIRkH8rIjFH';

// rzp_test_WPb7yQhn5Tdk1M 
// rzp_live_MqktIRkH8rIjFH
