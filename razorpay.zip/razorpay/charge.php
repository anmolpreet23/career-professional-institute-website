<?php
session_start();
$error = '';
$servername = ("localhost");
$username = ("root");
$password = ("");
$dbname = ("ecomm");
$conn =  mysqli_connect($servername, $username, $password,$dbname);
//connection

if (isset($_POST['submitform'])) {
} else {

    $_SESSION['payid']=$_POST['razorpay_payment_id'];
	$payid=$_POST['razorpay_payment_id'];
    header("refresh:1;url= http://localhost/ecommerce/sales.php?pay=$payid");
}
