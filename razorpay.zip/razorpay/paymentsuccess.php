<?php
session_start();
$servername = ("localhost");
$username = ("root");
$password = ("");
$dbname = ("ecomm");
$conn =  mysqli_connect($servername, $username, $password);
mysqli_select_db($conn, 'ecomm');
$sql = mysqli_query($conn, "SELECT * from sales WHERE pay_id='".$_SESSION['payid']."' ORDER BY id DESC LIMIT 1");
$printdata = mysqli_fetch_row($sql);
$pay = $printdata['2'];

/* Email Sent */

$to = "quadcommercestore@gmail.com";
$subject = "Order on Website";
 
$message = "<b><h2>Hi, Admin<br>A Product has been booked on website with following Payment ID:</h2></b><br>";
$message .= "<b>Payment ID: $pay</b>";
 
$header = "From:quadcommercestore@gmail.com \r\n";
$header .= "MIME-Version: 1.0\r\n";
$header .= "Content-type: text/html\r\n";
 
mail ($to,$subject,$message,$header);	

/*  Email Over */

/* Email Sent */

$toq = "abhishekmalik432@gmail.com";
$subjectq = "Appointment Booking Notification DOC2DOORS";
 
$messageq = "<b><h2>Hi, Abhishek<br>A Product has been ordered on our website with following ID:</h2></b><br>";
$messageq .= "<b>Payment ID: $pay</b>";
 
$headerq = "From:quadcommercestore@gmail.com \r\n";
$headerq .= "MIME-Version: 1.0\r\n";
$headerq .= "Content-type: text/html\r\n";
 
mail ($toq,$subjectq,$messageq,$headerq);	

/*  Email Over */

$apiKey = urlencode('2LJJv12vXtA-3xzgrNGkoSomCA1UfmWVUQZXeme50q	');
// Message details
$numbers = array($phone);
$sender = urlencode('DOCTDS');
$message = rawurlencode("Gr. Your OTP is $otp. Please reach the hospital 15 - 20 minutes prior to your appointment time and enquire with your name and OTP at the reception. If you face any problem feel free to call our helpline number - 70436-36176.
 Get Well soon. Have a nice day");

$numbers = implode(',', $numbers);

// Prepare data for POST request
$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);

// Send the POST request with cURL
$ch = curl_init('https://api.textlocal.in/send/');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

?>

<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Payment Successful - Doc2doors.com</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Favicons -->
  <link href="images/favicon.jpg" rel="icon">
  <link href="images/favicon.jpg" rel="apple-touch-icon">
  <style>
    .razorpay-payment-button {
      font-family: "Poppins", sans-serif;
      font-weight: 500;
      font-size: 14px;
      letter-spacing: 0.5px;
      display: inline-block;
      padding: 14px 50px;
      border-radius: 5px;
      transition: 0.5s;
      margin-top: 30px;
      color: #fff;
      border: none;
      background: #2487ce;
    }
  </style>
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: OnePage - v2.1.0
  * Template URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container position-relative">
      <div class="row justify-content-center">
        <div class="col-xl-7 col-lg-9 text-center">
          <h3 style="color:green"><b>Successfully Booked</b></h3>
        </div>
      </div>

   <h2 class="description" style="font-size:20px">Your appointment has been booked. You will soon recieve a message on your phone number. Incase balance is deducted from your account but message has not been delivered. Please contact our helpline number.
   <br>
   <br>
   Message usually takes 2-5 minutes to arrive* 
   <br>
   <br>
   Thank you for booking your appointment through Doc2Doors. If you face any issues feel free to contact us at - 7043636176, 8875233228 or by Email - contact@doc2doors.com.
   <br>
   <br>
   Have a nice day. Get Well Soon &#128519.

              <br>
              <br>

              <a href="../index.php"><b>Go to Homepage</b></h2>


    </div>
  </section><!-- End Hero -->
