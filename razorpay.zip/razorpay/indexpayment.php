<?php

session_start();
if(isset($_SESSION['IS_LOGIN']))
{
$servername = ("103.21.59.188");
$username = ("doc2dsil_doc2doors");
$password = ("(l%*ZgTD+rdT");
$dbname = ("doc2dsil_doc2doors");
$conn =  mysqli_connect($servername, $username, $password);
mysqli_select_db($conn, 'doc2dsil_doc2doors');
require_once('config.php');

$amt=$_SESSION['amount'];
$extra=$_SESSION['extra'];
$total=$amt+$extra;
$sqlsa = "SELECT * FROM `specialists` WHERE id='".$_SESSION['service']."'";
$ressa = $conn->query($sqlsa);
while ($rowsa = mysqli_fetch_assoc($ressa)) {
	$service = $rowsa['title'];
}
$sqls = "SELECT * FROM `hospitals` WHERE hospital_name='".$_SESSION['hospital']."'";
$ress = $conn->query($sqls);
while ($rows = mysqli_fetch_assoc($ress)) {
	$hosid = $rows['id'];
}
?>

<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Payment Page - Doc2doors.com</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Favicons -->
  <link href="images/favicon.jpg" rel="icon">
  <link href="images/favicon.jpg" rel="apple-touch-icon">
  <STYLE type="text/css">
.right {
    background-color: white;
    padding: 20px 40px;
    margin-top: 30px;
    border-radius: .1875rem;
        box-shadow: 0px 0px 20px -4px;
}
#page_1 #p1dimg1 {position:absolute;top:15px;left:7px;z-index:-1;width:97px;height:57px;}
#page_1 #p1dimg1 #p1img1 {width:97px;height:57px;}




.ft0{font: 1px 'Calibri';line-height: 1px;}
.ft1{font: bold 27px 'Calibri';line-height: 33px;}
.ft2{font: 15px 'Calibri';line-height: 17px;}
.ft3{font: bold 15px 'Calibri';line-height: 17px;}
.ft4{font: 15px 'Calibri';line-height: 18px;}
.ft5{font: bold 15px 'Calibri';line-height: 18px;}
.ft6{font: 14px 'Calibri';line-height: 17px;}
.ft7{font: 15px 'Calibri';color: #444444;line-height: 18px;}
.ft8{font: 1px 'Calibri';line-height: 3px;}
.ft9{font: bold 14px 'Calibri';line-height: 17px;}
.ft10{font: bold 15px 'Calibri';line-height: 16px;}
.ft11{font: 1px 'Calibri';line-height: 16px;}
.ft12{font: 1px 'Calibri';line-height: 8px;}
.ft13{font: 1px 'Calibri';line-height: 12px;}
.ft14{font: italic bold 15px 'Calibri';line-height: 18px;}
.ft15{font: bold 16px 'Calibri';line-height: 19px;}
.ft16{font: bold 15px 'Arial';color: #202124;line-height: 18px;}
.ft17{font: 1px 'Calibri';line-height: 13px;}
.ft18{font: 11px 'Arial';line-height: 13px;}
.ft19{font: 8px 'Calibri';line-height: 10px;}

.p0{text-align: left;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p1{text-align: left;padding-left: 26px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p2{text-align: right;padding-right: 24px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p3{text-align: left;padding-left: 6px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p4{text-align: left;padding-left: 32px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p5{text-align: left;padding-left: 7px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p6{text-align: left;padding-left: 1px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p7{text-align: right;padding-right: 21px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p8{text-align: left;padding-left: 31px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p9{text-align: left;padding-left: 2px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p10{text-align: right;padding-right: 7px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p11{text-align: right;padding-right: 23px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p12{text-align: right;padding-right: 14px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p13{text-align: left;padding-left: 23px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p14{text-align: right;padding-right: 11px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p15{text-align: left;padding-left: 30px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p16{text-align: left;padding-left: 188px;margin-top: 97px;margin-bottom: 0px;}

.td0{border-left: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 38px;vertical-align: bottom;}
.td1{border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 6px;vertical-align: bottom;}
.td2{border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 141px;vertical-align: bottom;}
.td3{border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 48px;vertical-align: bottom;}
.td4{border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 98px;vertical-align: bottom;}
.td5{border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 47px;vertical-align: bottom;}
.td6{border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 69px;vertical-align: bottom;}
.td7{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 226px;vertical-align: bottom;}
.td8{border-left: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 38px;vertical-align: bottom;}
.td9{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 6px;vertical-align: bottom;}
.td10{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 141px;vertical-align: bottom;}
.td11{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 48px;vertical-align: bottom;}
.td12{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 98px;vertical-align: bottom;}
.td13{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 47px;vertical-align: bottom;}
.td14{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 69px;vertical-align: bottom;}
.td15{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 113px;vertical-align: bottom;}
.td16{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 27px;vertical-align: bottom;}
.td17{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 86px;vertical-align: bottom;}
.td18{border-left: #000000 1px solid;padding: 0px;margin: 0px;width: 38px;vertical-align: bottom;}
.td19{padding: 0px;margin: 0px;width: 6px;vertical-align: bottom;}
.td20{padding: 0px;margin: 0px;width: 141px;vertical-align: bottom;}
.td21{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 145px;vertical-align: bottom;}
.td22{padding: 0px;margin: 0px;width: 116px;vertical-align: bottom;}
.td23{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 226px;vertical-align: bottom;}
.td24{border-left: #000000 1px solid;padding: 0px;margin: 0px;width: 185px;vertical-align: bottom;}
.td25{padding: 0px;margin: 0px;width: 140px;vertical-align: bottom;}
.td26{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 86px;vertical-align: bottom;}
.td27{border-left: #000000 1px solid;padding: 0px;margin: 0px;width: 44px;vertical-align: bottom;}
.td28{padding: 0px;margin: 0px;width: 47px;vertical-align: bottom;}
.td29{padding: 0px;margin: 0px;width: 69px;vertical-align: bottom;}
.td30{padding: 0px;margin: 0px;width: 113px;vertical-align: bottom;}
.td31{padding: 0px;margin: 0px;width: 27px;vertical-align: bottom;}
.td32{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 97px;vertical-align: bottom;}
.td33{border-left: #000000 1px solid;border-bottom: #f2f2f2 1px solid;padding: 0px;margin: 0px;width: 44px;vertical-align: bottom;background: #f2f2f2;}
.td34{border-bottom: #f2f2f2 1px solid;padding: 0px;margin: 0px;width: 141px;vertical-align: bottom;background: #f2f2f2;}
.td35{border-right: #f2f2f2 1px solid;border-bottom: #f2f2f2 1px solid;padding: 0px;margin: 0px;width: 47px;vertical-align: bottom;background: #f2f2f2;}
.td36{border-right: #000000 1px solid;border-bottom: #f2f2f2 1px solid;padding: 0px;margin: 0px;width: 97px;vertical-align: bottom;background: #f2f2f2;}
.td37{border-right: #f2f2f2 1px solid;border-bottom: #f2f2f2 1px solid;padding: 0px;margin: 0px;width: 46px;vertical-align: bottom;background: #f2f2f2;}
.td38{border-bottom: #f2f2f2 1px solid;padding: 0px;margin: 0px;width: 69px;vertical-align: bottom;background: #f2f2f2;}
.td39{border-right: #f2f2f2 1px solid;border-bottom: #f2f2f2 1px solid;padding: 0px;margin: 0px;width: 112px;vertical-align: bottom;background: #f2f2f2;}
.td40{border-bottom: #f2f2f2 1px solid;padding: 0px;margin: 0px;width: 27px;vertical-align: bottom;background: #f2f2f2;}
.td41{border-right: #000000 1px solid;border-bottom: #f2f2f2 1px solid;padding: 0px;margin: 0px;width: 86px;vertical-align: bottom;background: #f2f2f2;}
.td42{border-left: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 185px;vertical-align: bottom;}
.td43{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 97px;vertical-align: bottom;}
.td44{border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 113px;vertical-align: bottom;}
.td45{border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 27px;vertical-align: bottom;}
.td46{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 86px;vertical-align: bottom;}
.td47{padding: 0px;margin: 0px;width: 48px;vertical-align: bottom;}
.td48{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 97px;vertical-align: bottom;}
.td49{border-left: #000000 1px solid;border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 37px;vertical-align: bottom;background: #f2f2f2;}
.td50{padding: 0px;margin: 0px;width: 6px;vertical-align: bottom;background: #f2f2f2;}
.td51{padding: 0px;margin: 0px;width: 141px;vertical-align: bottom;background: #f2f2f2;}
.td52{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 47px;vertical-align: bottom;background: #f2f2f2;}
.td53{border-right: #f2f2f2 1px solid;padding: 0px;margin: 0px;width: 97px;vertical-align: bottom;background: #f2f2f2;}
.td54{border-right: #f2f2f2 1px solid;padding: 0px;margin: 0px;width: 46px;vertical-align: bottom;background: #f2f2f2;}
.td55{padding: 0px;margin: 0px;width: 69px;vertical-align: bottom;background: #f2f2f2;}
.td56{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 112px;vertical-align: bottom;background: #f2f2f2;}
.td57{padding: 0px;margin: 0px;width: 27px;vertical-align: bottom;background: #f2f2f2;}
.td58{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 86px;vertical-align: bottom;background: #f2f2f2;}
.td59{border-left: #000000 1px solid;border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 37px;vertical-align: bottom;background: #f2f2f2;}
.td60{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 6px;vertical-align: bottom;background: #f2f2f2;}
.td61{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 141px;vertical-align: bottom;background: #f2f2f2;}
.td62{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 47px;vertical-align: bottom;background: #f2f2f2;}
.td63{border-right: #f2f2f2 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 97px;vertical-align: bottom;background: #f2f2f2;}
.td64{border-right: #f2f2f2 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 46px;vertical-align: bottom;background: #f2f2f2;}
.td65{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 69px;vertical-align: bottom;background: #f2f2f2;}
.td66{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 112px;vertical-align: bottom;background: #f2f2f2;}
.td67{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 27px;vertical-align: bottom;background: #f2f2f2;}
.td68{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 86px;vertical-align: bottom;background: #f2f2f2;}
.td69{border-left: #000000 1px solid;border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 37px;vertical-align: bottom;}
.td70{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 47px;vertical-align: bottom;}
.td71{padding: 0px;margin: 0px;width: 214px;vertical-align: bottom;}
.td72{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 112px;vertical-align: bottom;}
.td73{border-left: #000000 1px solid;border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 37px;vertical-align: bottom;}
.td74{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 47px;vertical-align: bottom;}
.td75{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 112px;vertical-align: bottom;}
.td76{padding: 0px;margin: 0px;width: 98px;vertical-align: bottom;}
.td77{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 46px;vertical-align: bottom;}
.td78{border-left: #000000 1px solid;padding: 0px;margin: 0px;width: 331px;vertical-align: bottom;}
.td79{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 140px;vertical-align: bottom;}
.td80{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 46px;vertical-align: bottom;}

.tr0{height: 64px;}
.tr1{height: 20px;}
.tr2{height: 17px;}
.tr3{height: 21px;}
.tr4{height: 3px;}
.tr5{height: 19px;}
.tr6{height: 38px;}
.tr7{height: 28px;}
.tr8{height: 16px;}
.tr9{height: 8px;}
.tr10{height: 12px;}
.tr11{height: 23px;}
.tr12{height: 60px;}
.tr13{height: 39px;}
.tr14{height: 27px;}
.tr15{height: 13px;}
.tr16{height: 305px;}

.t0{width: 674px;font: 15px 'Calibri';}

</STYLE>
  <style>
    .razorpay-payment-button {
      font-family: "Poppins", sans-serif;
      font-weight: 500;
      font-size: 14px;
      letter-spacing: 0.5px;
      display: inline-block;
      padding: 14px 50px;
      border-radius: 5px;
      transition: 0.5s;
      margin-top: 30px;
      color: #fff;
      border: none;
      background: #2487ce;
    }
    .modal {
        overflow:scroll !important;
    }
  </style>
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: OnePage - v2.1.0
  * Template URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

    <header id="header" class="fixed-top" style="background:aliceblue">
    <div class="container d-flex align-items-center">
      <a href="https://doc2doors.com/index.php" class="logo"><img src="images/logo-new.png" alt="" class="img-fluid"></a>
      <h1 class="logo mr-auto"><a href="https://doc2doors.com/index.php">Doc2Doors</a></h1>

      <nav class="nav-menu d-none d-lg-block" style="margin-right:10px">
        <ul>
          <li class="<?php if ($url == "https://doc2doors.com/index.php" || $url == "https://doc2doors.com/" || $url == "https://doc2doors.com") {
                        echo "active";
                      } ?>"><a href="https://doc2doors.com/index.php">Home</a></li>
          <li class="<?php if ($url == "https://doc2doors.com/about.php") {
                        echo "active";
                      } ?>"><a href="https://doc2doors.com/about.php">About Us</a></li>
          <li class="<?php if ($url == "https://doc2doors.com/contact.php") {
                        echo "active";
                      } ?>"><a href="https://doc2doors.com/contact.php">Contact</a></li>
          <li class="<?php if ($url == "https://doc2doors.com/services.php") {
                        echo "active";
                      } ?>"><a href="https://doc2doors.com/services.php">Services</a></li>
          <li class="<?php if ($url == "https://doc2doors.com/help.php") {
                        echo "active";
                      } ?>"><a href="https://doc2doors.com/help.php">Help</a></li>
          <li class="<?php if ($url == "https://doc2doors.com/blog.php") {
                        echo "active";
                      } ?>"><a href="https://doc2doors.com/blog.php">Blog</a></li>
        <li class="<?php if ($url == "https://doc2doors.com/join.php") {
                        echo "active";
                      } ?>"><a href="https://doc2doors.com/join.php">Join Us</a></li>

        </ul>
      </nav><!-- .nav-menu -->
      <?php if (!isset($_SESSION['IS_LOGIN'])) { ?>
        <a data-toggle="modal" href="#loginmodal" class="get-started-btn scrollto" style="color:white">Login</a>
      <?php } ?>
      <?php if (isset($_SESSION['IS_LOGIN']) && $_SESSION['ROLE'] == "0") { ?><div class="dropdown">
          <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown" style="font-weight:bold"><?php echo $_SESSION['username']; ?>
            <span class="caret"></span></button>
          <ul class="dropdown-menu" style="padding:10px">
            <li class="pl"><a href="../admin/index.php">Dashboard</a></li>
            <li class="divider"></li>
            <li class="pl"><a href="../admin/logout.php">Logout</a></li>
          </ul>
        </div>
      <?php } ?>
      <?php if (isset($_SESSION['IS_LOGIN']) && $_SESSION['ROLE'] == 2) { ?><div class="dropdown">
          <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown" style="font-weight:bold">Account
            <span class="caret"></span></button>
          <ul class="dropdown-menu" style="padding:10px">
            <li class="pl"><a href="../patient/index.php">Dashboard</a></li>
            <li class="divider"></li>
            <li class="pl"><a href="../patient/logout.php">Logout</a></li>
          </ul>
        </div>
      <?php } ?>
      <?php if (isset($_SESSION['IS_LOGIN']) && $_SESSION['ROLE'] == 1) { ?><div class="dropdown">
          <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown" style="font-weight:bold">Hospital Panel
            <span class="caret"></span></button>
          <ul class="dropdown-menu" style="padding:10px">
            <li class="pl"><a href="../hospital/index.php">Dashboard</a></li>
            <li class="divider"></li>
            <li class="pl"><a href="../hospital/logout.php">Logout</a></li>
          </ul>
        </div>
      <?php } ?>

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container position-relative">
      <div class="row justify-content-center">
        <div class="col-xl-7 col-lg-9 text-center">
          <h3>Consultation Fees: <b><?php echo $_SESSION['amount']; ?>/-</b></h3>
        </div>
      </div>

      <div class="row icon-boxes">
        <div class="col-md-6 col-lg-6 d-flex align-items-stretch mb-5 mb-lg-0" style="margin-top:3%">
          <div class="icon-box col-md-12">

            <h2 class="description" style="font-size:20px">Complete your Booking by paying through Razorpay Gateway. One of the
              most secure payment gateway service provider. We Provide you multiple
              payment options. You can pay through Credit-card/Debit-card,
              Wallets, UPI or Net-Banking. It's quick and safe!!
              <br>
              <br>

              <b>Do not refresh or click 'go back' while making the payment. If any problem arises feel free to contact us!</b></h2>
              <form name="submitform" action="charge.php" method="POST">
              <script src="https://checkout.razorpay.com/v1/checkout.js" data-key="<?php echo $api_key_id ?>" data-currency="INR" data-name="Doc2Doors" data-buttontext="Pay with Razorpay" data-amount=<?php echo $total; ?>00 data-description="Book your appointment with Doc2Doors ." data-image="../images/logo-new.png" data-prefill.name="" data-prefill.email="" data-prefill.contact="Phone Number" data-theme.color="#2e86c1">


              </script>
              </form>
          </div>
          
        </div>
        <div class="right col-md-6">
            <u><h2 class="cart-section-title" style="color:black;font-weight:bold">Appointment Summary (1)</h2></u><br><br>
            <div class="cart-order-details">
                <div class="item">
                    <div class="item-right">
                        <div class="list-item">Service: 
                            <a style="float:right" target="_blank" href="https://doc2doors.com/specialists.php?service=<?php echo $service; ?>&serviceid=<?php echo $_SESSION['service']; ?>">
                                <?php echo $service; ?>                           
                            </a>
                        </div>
                        <div class="list-item seller">
                            By Hospital : &nbsp;<a style="float:right"  target="_blank" href="https://doc2doors.com/hospital.php?id=<?php echo base64_encode($hosid); ?>&hs=<?php echo base64_encode($_SESSION['hospital']); ?>"><?php echo $_SESSION['hospital']; ?></a>
                        </div>
                        <div class="list-item">
                            <label>Appointment Date:</label>
                            <strong><span class="float-right"><?php echo $_SESSION['date']; ?></span></strong>
                        </div>
                        <div class="list-item">
                            <label>Appointment Time:</label>
                            <strong><span class="float-right"><?php echo $_SESSION['time']; ?></span></strong>
                        </div>
                        <div class="list-item">
                            <label>Concerned Doctor:</label>
                            <strong><span class="float-right"><?php echo $_SESSION['doctor']; ?></span></strong>
                        </div>
                        <div class="list-item">
                            <label>Hospital Charges:</label>
                            <strong><span class="float-right"><span>₹</span><?php echo $amt; ?></span></strong>
                        </div><hr>
                    </div>
                </div>
            </div>
            <p class="m-t-30">
                <strong>Subtotal<span class="float-right"><span>₹</span><?php echo $amt; ?></span></strong>
            </p>
            <p>
                Service Charges: <span class="float-right"><span>+ ₹</span><?php echo $extra; ?></span></span>
            </p>
            <hr>
            <p>
                <strong>Total<span class="float-right"><span>₹</span><?php echo $total; ?></span></strong>
            </p>
        </div>
      </div>


    </div>
  </section><!-- End Hero -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="container d-md-flex py-4">

      <div class="mr-md-auto text-center text-md-left">
        <div class="copyright">
          &copy; Copyright <strong><span>Doc2Doors.com 2020</span></strong>. All Rights Reserved<br>
          <a target="_blank" class="Privacypolicy" href="privacy.php" style="color:chocolate">Privacy Policy</a>
          &nbsp;&nbsp;&nbsp;&nbsp;
          <a target="_blank" class="TermsConditions" href="terms.php" style="color:chocolate">Terms &amp; Conditions</a>
          <a href="#" onclick="window.open('https://www.sitelock.com/verify.php?site=doc2doors.com','SiteLock','width=600,height=600,left=160,top=170');" ><img class="img-responsive" alt="SiteLock" title="SiteLock" src="//shield.sitelock.com/shield/doc2doors.com" /></a>
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/Doc2Doors-106442977813331" class="facebook" target="_blank"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/doc2doors/?hl=en/doc2doors" class="instagram" target="_blank"><i class="bx bxl-instagram"></i></a>
        <a href="https://twitter.com/doc2doors" class="twitter" target="_blank"><i class="bx bxl-twitter"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="ri-arrow-up-line"></i></a>
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <div class="modal fade" id="loginmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-lock"></i> &nbsp;&nbsp;Login</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <span><b><?php echo $err; ?></b></span>
            </div>
            <div class="modal-body">
                <form action="../loginsystem/login.php" method="post">
                     <div class="row">
						
                        <div class="form-group col-md-12">
                            <label>Email / Phone No :</label>
                            <input class="form-control" type="text" name="Username" placeholder="Email or Phone No." id="" required />
                        </div>

                        <div class="form-group col-md-12">
                            <label>Password:</label>
                            <input class="form-control" type="password" name="_Password" id="pwd" placeholder="********" required />
                        </div>
                        
                        <div class="form-group col-md-12"  style="cursor:pointer">
                            <input type="checkbox" onClick="myFunction()" name="agree" id="hide" />&nbsp;&nbsp;Show Password
                        </div>

                    </div>
                    <button name="submit" class="btn btn-primary" type="submit">
                        Login
                    </button>
                    </form>
                     
            </div>
            <div class="modal-footer" style="padding: .75rem !important;">
              <p style="font-size: 14px;">Hospital?  <a data-toggle="modal" class="hl" href="#hospitalloginmodal">Login here</a></p> |<br>
              <p style="font-size: 14px;">New member?  <a data-toggle="modal" class="r" href="#registermodal">Create New Account</a></p>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="hospitalloginmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-lock"></i> &nbsp;&nbsp;Hospital Login</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <span><b><?php echo $err; ?></b></span>
            </div>
            <div class="modal-body">
                <form action="../loginsystem/hospital-login.php" method="post">
                     <div class="row">
						
                        <div class="form-group col-md-12">
                            <label>Username :</label>
                            <input class="form-control" type="text" name="Username" placeholder="Username...." id="" required />
                        </div>

                        <div class="form-group col-md-12">
                            <label>Password:</label>
                            <input class="form-control" type="password" name="_Password" id="pwd1" placeholder="********" required />
                        </div>
                        
                        <div class="form-group col-md-12"  style="cursor:pointer">
                            <input type="checkbox" onClick="myFunction1()" name="agree" id="hide1" />&nbsp;&nbsp;Show Password
                        </div>
                    </div>
                    <button name="submit" class="btn btn-primary" type="submit">
                        Login
                    </button>
                    </form>
            </div>
            <div class="modal-footer" style="padding: .75rem !important;">
              <p style="font-size: 14px;">User?  <a data-toggle="modal" class="usl" href="#loginmodal">Login here</a></p> |<br>
              <p style="font-size: 14px;">Register Hospital?  <a href="https://doc2doors.com/join.php">Register Hospital</a></p>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="registermodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-check-square-o"></i> &nbsp;&nbsp;Register as Patient</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <span><b><?php echo $err; ?></b></span>
            </div>
            <div class="modal-body">
                <form action="../loginsystem/register.php" method="post">
                     <div class="row">
						
                        <div class="form-group col-md-12">
                            <label>First Name :</label>
                            <input class="form-control" type="text" name="fname" placeholder="First Name" id="" required />
                        </div>
                        
                        <div class="form-group col-md-12">
                            <label>Last Name :</label>
                            <input class="form-control" type="text" name="lname" placeholder="Last Name" id="" required />
                        </div>
                        
                        <div class="form-group col-md-12">
                            <label>Contact No :</label>
                            <input class="form-control" type="number" maxlength="10" name="phone" placeholder="Contact No." id="" required />
                        </div>
                        
                        <div class="form-group col-md-12">
                            <label>Password:</label>
                            <input class="form-control" type="password" name="_Password" id="pwd2" placeholder="********" required />
                        </div>
                        
                        <div class="form-group col-md-12">
                            <label>Confirm Password:</label>
                            <input class="form-control" type="password" name="c_Password" id="cpwd2" placeholder="********" required />
                        </div>
                        
                        <div class="form-group col-md-12">
                            <label>Refer Code (if any):</label>
                            <input class="form-control" type="text" name="refer" placeholder="Refer Code" />
                        </div>
                        
                        <div class="form-group col-md-12"  style="cursor:pointer">
                            <input type="checkbox" onClick="myFunction2()" name="agree" id="hide2" />&nbsp;&nbsp;Show Password
                        </div>
                    </div>
                    <button name="submit" class="btn btn-primary" type="submit">
                        Register
                    </button>
                    </form>
            </div>
        </div>
    </div>
</div>
<script>
    function myFunction() {
      var x = document.getElementById("pwd");
      var z = document.getElementById("hide");
      if (x.type === "password") {
        x.type = "text";		
      } else {
        x.type = "password";
      }
      return false;
    }
    function myFunction2() {
      var x = document.getElementById("pwd2");
      var y = document.getElementById("cpwd2");
      var z = document.getElementById("hide2");
      if (x.type === "password" && y.type === "password") {
        x.type = "text";		
        y.type = "text";		
      } else {
        x.type = "password";
        y.type = "password";
      }
      return false;
    }
    function myFunction1() {
      var x = document.getElementById("pwd1");
      var z = document.getElementById("hide1");
      if (x.type === "password") {
        x.type = "text";		
      } else {
        x.type = "password";
      }
      return false;
    }
    </script>
    <script>
     $(document).on('click', '.hl', function() {
        $('#loginmodal').modal('hide');
        $('#registermodal').modal('hide');
     });
      $(document).on('click', '.usl', function() {
        $('#hospitalloginmodal').modal('hide');
        $('#registermodal').modal('hide');
     });
     $(document).on('click', '.r', function() {
        $('#loginmodal').modal('hide');
        $('#hospitalloginmodal').modal('hide');
     });
    </script>
</body>

</html>
<?php }else{ 
    session_destroy();
header("Location: https://doc2doors.com/");
 } ?>