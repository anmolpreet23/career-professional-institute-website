<?php
function numberTowords($num)
{
    $ones = array(
        0 =>"ZERO",
        1 => "ONE",
        2 => "TWO",
        3 => "THREE",
        4 => "FOUR",
        5 => "FIVE",
        6 => "SIX",
        7 => "SEVEN",
        8 => "EIGHT",
        9 => "NINE",
        10 => "TEN",
        11 => "ELEVEN",
        12 => "TWELVE",
        13 => "THIRTEEN",
        14 => "FOURTEEN",
        15 => "FIFTEEN",
        16 => "SIXTEEN",
        17 => "SEVENTEEN",
        18 => "EIGHTEEN",
        19 => "NINETEEN",
        "014" => "FOURTEEN"
    );
    $tens = array( 
        0 => "ZERO",
        1 => "TEN",
        2 => "TWENTY",
        3 => "THIRTY", 
        4 => "FORTY", 
        5 => "FIFTY", 
        6 => "SIXTY", 
        7 => "SEVENTY", 
        8 => "EIGHTY", 
        9 => "NINETY" 
    ); 
    $hundreds = array( 
        "HUNDRED", 
        "THOUSAND", 
        "MILLION", 
        "BILLION", 
        "TRILLION", 
        "QUARDRILLION" 
    );
    $num = number_format($num,2,".",","); 
    $num_arr = explode(".",$num); 
    $wholenum = $num_arr[0]; 
    $decnum = $num_arr[1]; 
    $whole_arr = array_reverse(explode(",",$wholenum)); 
    krsort($whole_arr,1); 
    $rettxt = ""; 
    foreach($whole_arr as $key => $i)
    {
        while(substr($i,0,1)=="0")
		    $i=substr($i,1,5);
        if($i < 20)
        { 
            $rettxt .= $ones[$i]; 
        }
        elseif($i < 100)
        { 
            if(substr($i,0,1)!="0")  $rettxt .= $tens[substr($i,0,1)]; 
            if(substr($i,1,1)!="0") $rettxt .= " ".$ones[substr($i,1,1)]; 
        }
        else
        { 
            if(substr($i,0,1)!="0") $rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0]; 
            if(substr($i,1,1)!="0")$rettxt .= " ".$tens[substr($i,1,1)]; 
            if(substr($i,2,1)!="0")$rettxt .= " ".$ones[substr($i,2,1)]; 
        } 
        if($key > 0)
        { 
            $rettxt .= " ".$hundreds[$key]." "; 
        }
    } 
    if($decnum > 0)
    {
        $rettxt .= " and ";
        if($decnum < 20)
        {
            $rettxt .= $ones[$decnum];
        }
        elseif($decnum < 100)
        {
            $rettxt .= $tens[substr($decnum,0,1)];
            $rettxt .= " ".$ones[substr($decnum,1,1)];
        }
    }
    return $rettxt;
}
?>

<DIV id="page_1">
<DIV id="p1dimg1">
<IMG src="https://doc2doors.com/images/logo-new.png" id="p1img1"></DIV>


<TABLE cellpadding=0 cellspacing=0 class="t0">
<TR>
	<TD class="tr0 td0"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr0 td1"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr0 td2"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr0 td3"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr0 td4"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr0 td5"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr0 td6"><P class="p0 ft0">&nbsp;</P></TD>
	<TD colspan=3 class="tr0 td7"><P class="p1 ft1">Doc2Doors.com</P></TD>
</TR>
<TR>
	<TD class="tr1 td8"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td9"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td10"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td11"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td12"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td13"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td14"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td15"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td16"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td17"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr2 td18"><P class="p2 ft2">#</P></TD>
	<TD class="tr2 td19"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr2 td20"><P class="p0 ft0">&nbsp;</P></TD>
	<TD colspan=2 class="tr2 td21"><P class="p0 ft3">: <NOBR>INV-000981</NOBR></P></TD>
	<TD colspan=2 class="tr2 td22"><P class="p3 ft2">Place of Supply</P></TD>
	<TD colspan=3 class="tr2 td23"><P class="p4 ft3">: Mumbai , Gujarat</P></TD>
</TR>
<TR>
	<TD colspan=3 class="tr1 td24"><P class="p5 ft4">Invoice Date</P></TD>
	<TD colspan=2 class="tr1 td21"><P class="p6 ft5">: 02/Mar/2021</P></TD>
	<TD colspan=2 class="tr1 td22"><P class="p3 ft4">Contact No</P></TD>
	<TD colspan=2 class="tr1 td25"><P class="p7 ft5">: <NOBR>70436-36176</NOBR></P></TD>
	<TD class="tr1 td26"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
<TR>
	<TD colspan=2 class="tr3 td27"><P class="p5 ft6">Terms</P></TD>
	<TD class="tr3 td20"><P class="p0 ft0">&nbsp;</P></TD>
	<TD colspan=2 class="tr3 td21"><P class="p0 ft5">: Due on Receipt</P></TD>
	<TD colspan=2 class="tr3 td22"><P class="p3 ft7">Email</P></TD>
	<TD colspan=3 class="tr3 td23"><P class="p8 ft5">: contact@doc2doors.com</P></TD>
</TR>
<TR>
	<TD colspan=3 class="tr3 td24"><P class="p5 ft4">Due Date</P></TD>
	<TD colspan=2 class="tr3 td21"><P class="p9 ft5">: 02/Mar/2021</P></TD>
	<TD class="tr3 td28"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td29"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td30"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td31"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td26"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr4 td8"><P class="p0 ft8">&nbsp;</P></TD>
	<TD class="tr4 td9"><P class="p0 ft8">&nbsp;</P></TD>
	<TD class="tr4 td10"><P class="p0 ft8">&nbsp;</P></TD>
	<TD class="tr4 td11"><P class="p0 ft8">&nbsp;</P></TD>
	<TD class="tr4 td32"><P class="p0 ft8">&nbsp;</P></TD>
	<TD class="tr4 td13"><P class="p0 ft8">&nbsp;</P></TD>
	<TD class="tr4 td14"><P class="p0 ft8">&nbsp;</P></TD>
	<TD class="tr4 td15"><P class="p0 ft8">&nbsp;</P></TD>
	<TD class="tr4 td16"><P class="p0 ft8">&nbsp;</P></TD>
	<TD class="tr4 td17"><P class="p0 ft8">&nbsp;</P></TD>
</TR>
<TR>
	<TD colspan=2 class="tr5 td33"><P class="p5 ft9">Bill To</P></TD>
	<TD class="tr5 td34"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr5 td35"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr5 td36"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr5 td37"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr5 td38"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr5 td39"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr5 td40"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr5 td41"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
<TR>
	<TD colspan=3 class="tr6 td42"><P class="p5 ft5">Abhishek Malik</P></TD>
	<TD class="tr6 td3"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr6 td43"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr6 td5"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr6 td6"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr6 td44"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr6 td45"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr6 td46"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
<TR>
	<TD colspan=3 class="tr1 td24"><P class="p5 ft4">Ludhiana</P></TD>
	<TD class="tr1 td47"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td48"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td28"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td29"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td30"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td31"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td26"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
<TR>
	<TD colspan=3 class="tr3 td24"><P class="p5 ft4">Punjab</P></TD>
	<TD class="tr3 td47"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td48"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td28"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td29"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td30"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td31"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td26"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
<TR>
	<TD colspan=3 class="tr1 td24"><P class="p5 ft4">Abhishek@yopmail.com</P></TD>
	<TD class="tr1 td47"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td48"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td28"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td29"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td30"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td31"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td26"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr7 td8"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td9"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td10"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td11"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td32"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td13"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td14"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td15"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td16"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td17"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr8 td49"><P class="p5 ft10">#</P></TD>
	<TD class="tr8 td50"><P class="p0 ft11">&nbsp;</P></TD>
	<TD class="tr8 td51"><P class="p0 ft10">Service</P></TD>
	<TD class="tr8 td52"><P class="p0 ft11">&nbsp;</P></TD>
	<TD class="tr8 td53"><P class="p3 ft10">Hospital</P></TD>
	<TD class="tr8 td54"><P class="p0 ft11">&nbsp;</P></TD>
	<TD class="tr8 td55"><P class="p0 ft11">&nbsp;</P></TD>
	<TD class="tr8 td56"><P class="p0 ft11">&nbsp;</P></TD>
	<TD class="tr8 td57"><P class="p0 ft11">&nbsp;</P></TD>
	<TD class="tr8 td58"><P class="p10 ft10">Amount</P></TD>
</TR>
<TR>
	<TD class="tr9 td59"><P class="p0 ft12">&nbsp;</P></TD>
	<TD class="tr9 td60"><P class="p0 ft12">&nbsp;</P></TD>
	<TD class="tr9 td61"><P class="p0 ft12">&nbsp;</P></TD>
	<TD class="tr9 td62"><P class="p0 ft12">&nbsp;</P></TD>
	<TD class="tr9 td63"><P class="p0 ft12">&nbsp;</P></TD>
	<TD class="tr9 td64"><P class="p0 ft12">&nbsp;</P></TD>
	<TD class="tr9 td65"><P class="p0 ft12">&nbsp;</P></TD>
	<TD class="tr9 td66"><P class="p0 ft12">&nbsp;</P></TD>
	<TD class="tr9 td67"><P class="p0 ft12">&nbsp;</P></TD>
	<TD class="tr9 td68"><P class="p0 ft12">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr2 td69"><P class="p11 ft2">1</P></TD>
	<TD class="tr2 td19"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr2 td20"><P class="p0 ft2">Endotonics</P></TD>
	<TD class="tr2 td70"><P class="p0 ft0">&nbsp;</P></TD>
	<TD colspan=3 class="tr2 td71"><P class="p3 ft2">Madhya Care Eye Hospital</P></TD>
	<TD class="tr2 td72"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr2 td31"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr2 td26"><P class="p12 ft2">24,000.00</P></TD>
</TR>
<TR>
	<TD class="tr10 td73"><P class="p0 ft13">&nbsp;</P></TD>
	<TD class="tr10 td9"><P class="p0 ft13">&nbsp;</P></TD>
	<TD class="tr10 td10"><P class="p0 ft13">&nbsp;</P></TD>
	<TD class="tr10 td74"><P class="p0 ft13">&nbsp;</P></TD>
	<TD class="tr10 td12"><P class="p0 ft13">&nbsp;</P></TD>
	<TD class="tr10 td13"><P class="p0 ft13">&nbsp;</P></TD>
	<TD class="tr10 td14"><P class="p0 ft13">&nbsp;</P></TD>
	<TD class="tr10 td75"><P class="p0 ft13">&nbsp;</P></TD>
	<TD class="tr10 td16"><P class="p0 ft13">&nbsp;</P></TD>
	<TD class="tr10 td17"><P class="p0 ft13">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr2 td18"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr2 td19"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr2 td20"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr2 td47"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr2 td76"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr2 td77"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr2 td29"><P class="p0 ft0">&nbsp;</P></TD>
	<TD colspan=2 class="tr2 td25"><P class="p13 ft2">Sub Total</P></TD>
	<TD class="tr2 td26"><P class="p14 ft2"><?php echo number_format($_SESSION['amount']); ?>.00</P></TD>
</TR>
<TR>
	<TD colspan=3 class="tr1 td24"><P class="p5 ft4">Total in words</P></TD>
	<TD class="tr1 td47"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td76"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td77"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr1 td29"><P class="p0 ft0">&nbsp;</P></TD>
	<TD colspan=2 class="tr1 td25"><P class="p0 ft4">Extra Charges</P></TD>
	<TD class="tr1 td26"><P class="p14 ft4"><?php echo number_format($_SESSION['extra']); ?>.00</P></TD>
</TR>
<?php $total=$_SESSION['amount']+$_SESSION['extra']; ?>
<TR>
	<TD colspan=5 class="tr11 td78"><P class="p5 ft14">Rupees <?php echo numberTowords("$total"); ?> only</P></TD>
	<TD class="tr11 td77"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr11 td29"><P class="p0 ft0">&nbsp;</P></TD>
	<TD colspan=2 class="tr11 td25"><P class="p0 ft15">Grand Total</P></TD>
	<TD class="tr11 td26"><P class="p0 ft15"><SPAN class="ft16">₹ </SPAN><?php echo number_format($total); ?>.00</P></TD>
</TR>
<TR>
	<TD colspan=5 rowspan=2 class="tr12 td78"><P class="p5 ft4">Thanks to give us chance to serve you.</P></TD>
	<TD class="tr13 td77"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr6 td14"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr6 td15"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr6 td16"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr6 td17"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr3 td77"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td29"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td30"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td31"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr3 td26"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr7 td18"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td19"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td20"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td47"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td76"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr7 td77"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr14 td14"><P class="p0 ft0">&nbsp;</P></TD>
	<TD colspan=2 class="tr14 td79"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr14 td17"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr15 td18"><P class="p0 ft17">&nbsp;</P></TD>
	<TD class="tr15 td19"><P class="p0 ft17">&nbsp;</P></TD>
	<TD class="tr15 td20"><P class="p0 ft17">&nbsp;</P></TD>
	<TD class="tr15 td47"><P class="p0 ft17">&nbsp;</P></TD>
	<TD class="tr15 td76"><P class="p0 ft17">&nbsp;</P></TD>
	<TD class="tr15 td77"><P class="p0 ft17">&nbsp;</P></TD>
	<TD class="tr15 td29"><P class="p0 ft17">&nbsp;</P></TD>
	<TD colspan=2 class="tr15 td25"><P class="p15 ft18">Authorized Signature</P></TD>
	<TD class="tr15 td26"><P class="p0 ft17">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr16 td8"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr16 td9"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr16 td10"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr16 td11"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr16 td12"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr16 td80"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr16 td14"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr16 td15"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr16 td16"><P class="p0 ft0">&nbsp;</P></TD>
	<TD class="tr16 td17"><P class="p0 ft0">&nbsp;</P></TD>
</TR>
</TABLE>
</DIV>